# FastBackup

## Problems on transmission
* Amount
* Size